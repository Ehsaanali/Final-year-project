
from django.urls import path
from . import views
urlpatterns =[
path('',views.epi, name='epi'),




]






