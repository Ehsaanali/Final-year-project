from django.db import models

# Create your models here.
class EpiProgram(models.Model):
    
    District = models.TextField()
    Infant_Immunization_started = models.IntegerField()
    Live_Births = models.IntegerField()
    Immunization_completed = models.IntegerField()
    Total_childern = models.IntegerField()
    Still_births = models.IntegerField()

    def __str__(self):
        return self.District

