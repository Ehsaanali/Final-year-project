from django.apps import AppConfig


class EpiConfig(AppConfig):
    name = 'epi'
