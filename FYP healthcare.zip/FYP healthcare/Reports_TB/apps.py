from django.apps import AppConfig


class ReportsTbConfig(AppConfig):
    name = 'Reports_TB'
