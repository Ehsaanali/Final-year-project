from django.shortcuts import render

from menuapi.models import TbProgram

# Create your views here.
def Reports_TB(request):
    
    context = TbProgram.objects.all().values()
     

    return render(request,'Reports_TB.html',{'context':context})
    