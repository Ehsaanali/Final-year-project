from django.apps import AppConfig


class LhwConfig(AppConfig):
    name = 'LHW'
