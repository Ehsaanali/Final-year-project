from django.contrib import admin
from .models import LhwProgram

admin.site.register(LhwProgram)