from django.db import models

# Create your models here.
class LhwProgram(models.Model):
    
    Division = models.TextField()
    Total_Dileveries = models.IntegerField()
    Live_Births = models.IntegerField()
    Still_births = models.IntegerField()
    Infant_Deaths = models.IntegerField()
    Neo_Natal_Deaths = models.IntegerField()
    Immunization_completed = models.IntegerField()

    def __str__(self):
        return self.Division

