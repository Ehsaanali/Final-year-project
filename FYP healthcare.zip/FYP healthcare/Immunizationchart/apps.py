from django.apps import AppConfig


class ImmunizationchartConfig(AppConfig):
    name = 'Immunizationchart'
