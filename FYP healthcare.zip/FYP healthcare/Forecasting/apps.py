from django.apps import AppConfig


class ForecastingConfig(AppConfig):
    name = 'Forecasting'
