
from django.urls import path
from . import views
urlpatterns =[
path('Forecasting',views.Forecasting, name='Forecasting'),
path('resultarea',views.resultarea)




]






