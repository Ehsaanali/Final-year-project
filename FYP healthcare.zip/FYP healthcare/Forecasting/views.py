from django.shortcuts import render;
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression 
from sklearn import metrics
import numpy as np
from sklearn.preprocessing import LabelEncoder
from scipy import stats

def Forecasting(request):
    return render(request, "Forecasting.html")
def resultarea(request):
    data =pd.read_csv(r"C:\Users\Ehsaan/2017_2018_2019_2020.csv")
    
    le = LabelEncoder()
    
    dfle = data
    le.fit_transform(dfle.District)
    dfle.District = le.fit_transform(dfle.District)
    
    pdata = np.abs(stats.zscore(data))
    df = data[(pdata<3).all(axis=1)]
    
    x = data.drop('Total Pop Covered', axis=1)
   
    y =data['Total Pop Covered']
    
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=.30)
    model = LinearRegression()
    model.fit(x_train, y_train)
    var1= int(request.GET['m1'])
    var2= int(request.GET['m2'])
    var3= int(request.GET['m3'])
    var4= int(request.GET['m4'])
    var5= int(request.GET['m5'])
    var6= int(request.GET['m6'])
    var7= int(request.GET['m7'])
    var8= int(request.GET['m8'])
    var10= int(request.GET['m10'])
    var11= int(request.GET['m11'])
    var12= int(request.GET['m12'])
    var13= int(request.GET['m13'])
    var14= int(request.GET['m14'])
    var15= int(request.GET['m15'])
    var18= int(request.GET['m18'])
    var19= int(request.GET['m19'])
    var20= int(request.GET['m20'])
    var21= int(request.GET['m21'])
    var22= int(request.GET['m22'])
    var23= int(request.GET['m23'])
    
    lst = []

    pred = model.predict(np.array([var1, var2, var3, var4 , var5, var6 ,var7, var8]).reshape(1, -1))
    pred1 = model.predict(np.array([var1, var10, var11, var12 , var13,  var14, var15, var8]).reshape(1, -1))
    pred2 = model.predict(np.array([var1, var18, var19, var20 , var21, var22 , var23, var8]).reshape(1, -1))
    pred = round(pred[0])
    pred1 = round(pred1[0])
    pred2 = round(pred2[0])
    p =[pred, pred1, pred2]
    
    lst.append(p)
    arr = np.array(lst)
    num = arr.tolist() 
        
        
    return render(request, "Forecasting.html",{"result2": num})



