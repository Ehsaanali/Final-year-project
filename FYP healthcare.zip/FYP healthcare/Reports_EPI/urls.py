
from django.urls import path
from . import views
urlpatterns =[
path('',views.Reports_EPI, name='Reports_EPI'),




]






