from django.apps import AppConfig


class ReportsEpiConfig(AppConfig):
    name = 'Reports_EPI'
