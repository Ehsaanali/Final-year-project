from django.shortcuts import render
from epi.models import EpiProgram


# Create your views here.
def Reports_EPI(request):
    
    context = EpiProgram.objects.all().values()
     

    return render(request,'Reports_EPI.html',{'context':context})
    