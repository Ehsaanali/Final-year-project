from django.apps import AppConfig


class InfantDeathConfig(AppConfig):
    name = 'infant_death'
