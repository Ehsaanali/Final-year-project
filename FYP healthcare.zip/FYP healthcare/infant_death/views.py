import pandas as pd
import numpy as np
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics
from sklearn.metrics import mean_squared_error
from django.shortcuts import render
from scipy import stats

def infant_death(request):
    return render(request, "infant_death.html")
def result(request):
    df =pd.read_csv(r"C:\Users\Ehsaan/For_Infant_Death_2018_2019_2020.csv")
    df = df.drop(['District'], axis=1)
    null = pd.isnull(df)
    
    pdata = np.abs(stats.zscore(df))
    X = df.drop( 'Infant Deaths', axis=1)
    Y = df['Infant Deaths']
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=.30)

#Step 6: Training and Predicting
    model = LinearRegression()
    model.fit(X_train, Y_train)
    predictions = model.predict(X_test)
    predictions

    mse=mean_squared_error(Y_test,predictions)
    rmse=np.sqrt(mse)
    r2_score=model.score(X_test,Y_test)
    var1= int(request.GET['m1'])
    var2= int(request.GET['m2'])
    var3= int(request.GET['m3'])
    var4= int(request.GET['m4'])
    var5= int(request.GET['m5'])
    var6= int(request.GET['m6'])
    var7= int(request.GET['m7'])
    var8= int(request.GET['m8'])
    var9= int(request.GET['m9'])
    var10= int(request.GET['m10'])
    var11= int(request.GET['m11'])
    var12= int(request.GET['m12'])
    var13= int(request.GET['m13'])
    var14= int(request.GET['m14'])
    var15= int(request.GET['m15'])
    lst = []

    pred = model.predict(np.array([var1, var2, var3, var4 , var5]).reshape(1, -1))
    pred1 = model.predict(np.array([var6, var7, var8, var9 , var10]).reshape(1, -1))
    pred2 = model.predict(np.array([var11, var12, var13, var14 , var15]).reshape(1, -1))
    pred = round(pred[0])
    pred1 = round(pred1[0])
    pred2 = round(pred2[0])
    p =[pred, pred1, pred2]
    
    lst.append(p)
    arr = np.array(lst)
    num = arr.tolist() 
     

    
    
    return render(request, "infant_death.html",{"result2": num})

