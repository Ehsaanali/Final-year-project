
from django.urls import path
from . import views
urlpatterns =[
path('infant_death',views.infant_death, name='infant_death'),
path('result',views.result)




]









