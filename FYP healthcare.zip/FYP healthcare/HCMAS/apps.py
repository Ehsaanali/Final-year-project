from django.apps import AppConfig


class HcmasConfig(AppConfig):
    name = 'HCMAS'
