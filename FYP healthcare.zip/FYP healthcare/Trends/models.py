from django.db import models

# Create your models here.
class Trends(models.Model):
    
    Years = models.IntegerField()
    Banbhore = models.IntegerField()
    Hyderabad = models.IntegerField()
    Karachi = models.IntegerField()
    Larkana = models.IntegerField()

    def __int__(self):
        return self.Years

