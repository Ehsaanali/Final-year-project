from django.contrib import admin
from .models import LHW_Areawise

admin.site.register(LHW_Areawise)

# Register your models here.
