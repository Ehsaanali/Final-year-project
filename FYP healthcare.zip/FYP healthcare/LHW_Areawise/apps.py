from django.apps import AppConfig


class LhwAreawiseConfig(AppConfig):
    name = 'LHW_Areawise'
