from django.urls import path
from . import views
urlpatterns =[
path('',views.LHWAreawise, name='LHWAreawise'),




]









