

from django.db import models

# Create your models here.
class Division(models.Model):
    div_name = models.CharField(max_length=50)
    Total_Cases = models.IntegerField()
    Treatement_Completed = models.IntegerField()
    Treatement_Incompleted = models.IntegerField()
    No_of_Death = models.IntegerField()

    class Meta:
        verbose_name_plural = "Division"
    

    def __str__(self):
        return self.div_name

# Create your models here.
class TbProgram(models.Model):
    
    Division = models.TextField()
    TOTAl_PATIENTS = models.IntegerField()
    CURED = models.IntegerField()
    TREATMENT_COMPLETED = models.IntegerField()
    TREATMENT_FAILED = models.IntegerField()
    DIED = models.IntegerField()
    years = models.IntegerField()
    Noofdeaths = models.IntegerField()

    def __str__(self):
        return self.Division

class TbProgramReport(models.Model):
    
    Quarter= models.TextField() 
    Total_Patients = models.IntegerField()
    New_Patients = models.IntegerField()
    Relapse = models.IntegerField()
    Treatment_After_Failure = models.IntegerField()
    Lost_To_Follow_UP = models.IntegerField()
    

    def __str__(self):
        return self.Quarter





