from django.apps import AppConfig


class MenuapiConfig(AppConfig):
    name = 'menuapi'
