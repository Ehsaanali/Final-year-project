from django.contrib import admin
from .models import Division
from .models import TbProgram
from .models import TbProgramReport
admin.site.register(Division)
admin.site.register(TbProgram)
admin.site.register(TbProgramReport)



# Register your models here.