from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from django.contrib import admin
from .models import LHW_Performance


@admin.register(LHW_Performance)
class PersonAdmin(ImportExportModelAdmin):
    list_display = ('District', 'Due_Reports', 'Submitted_Reports')
# Register your models here.
