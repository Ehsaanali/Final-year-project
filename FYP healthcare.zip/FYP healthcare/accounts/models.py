from django.db import models
class showusers(models.Model):
    username=models.CharField(max_length=100)

class LHW_Performance(models.Model):
    
    District = models.TextField(max_length=255)
    Due_Reports = models.IntegerField()
    Submitted_Reports = models.IntegerField()
    def __str__(self):
        return self.District


