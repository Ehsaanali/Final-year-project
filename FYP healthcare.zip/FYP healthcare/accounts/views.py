from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.models import User,auth
from django.contrib.auth import views as views_auth
from django.contrib.auth import get_user_model
import openpyxl
from LHW_ReportsWise.models import LHW_ReportsWisee

from django.http import HttpResponse
from .resources import LHW_PerformanceResource
from tablib import Dataset
from .models import LHW_Performance



# Create your views here.

def login(request):
    if request.method=='POST':
        username = request.POST['username']
        
        password = request.POST['password']
        user = auth.authenticate(username=username,password=password)
      
        
        if user is not None:
            auth.login(request, user)
            if request.user.is_authenticated and request.user.is_superuser:
                return redirect("admin_dashboard")
          
            return redirect("dashboard")
            
        else:
            messages.info(request,'invalid credentials')
            return redirect('login')
    else :
        return render(request,'login.html')

def admin_login(request):
    return render(request,'admin_login.html')



def register(request):
    if request.method =='POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email']
        if password1 == password2: 
            if User.objects.filter(username=username).exists():
                messages.info(request,'Username Taken')
                return redirect('register')
            elif User.objects.filter(email=email).exists():
                messages.info(request,'Email Taken')
                return redirect('register')
            else:
                user = User.objects.create_user(username=username,password=password1,email=email,first_name=first_name,last_name=last_name)
                user.save();
                print('user created')
                return redirect('showusers')
        else:
            messages.info(request,'Password is not matching')
            return redirect('register')
        return redirect('/')
        
    else :
        return render(request,'register.html')

def Finalarea(request):
    return render(request,'Finalarea.html')
def table(request):
    return render(request,'table.html') 
def doctors(request):
    return render(request,'doctors.html')
def dashboard(request):
    return render(request,'dashboard.html')  


def export(request):
    person_resource = LHW_PerformanceResource()
    dataset = person_resource.export()
    response = HttpResponse(dataset.xls, content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename="LHW_Performance.xls"'
    return response

def admin_dashboard(request):
    if request.method == 'POST':
        LHW_Performance_resource = LHW_PerformanceResource()
        dataset = Dataset()
        new_LHW_Performance = request.FILES['myfile']

        imported_data = dataset.load(new_LHW_Performance.read(),format='xlsx')
        #print(imported_data)
        for data in imported_data:
        	print(data[1])
        	value = LHW_Performance(
        		data[0],
        		data[1],
        		 data[2],
        		 data[3]
        		)
        	value.save()
        messages.info(request,'File uploaded sucessfully')       
        
        #result = person_resource.import_data(dataset, dry_run=True)  # Test the data import

        #if not result.has_errors():
        #    person_resource.import_data(dataset, dry_run=False)  # Actually import now

    

    return render(request, 'admin_dashboard.html')

    
    

def showusers(request):
 
    User = get_user_model()
    context = User.objects.values()
    
    return render(request,'showusers.html',{'context':context})








def simple_upload(request):
    if request.method == 'POST':
        person_resource = PersonResource()
        dataset = Dataset()
        new_persons = request.FILES['myfile']

        imported_data = dataset.load(new_persons.read(),format='xlsx')
        #print(imported_data)
        for data in imported_data:
        	print(data[1])
        	value = Person(
        		data[0],
        		data[1],
        		 data[2],
        		 data[3]
        		)
        	value.save()       
        
        #result = person_resource.import_data(dataset, dry_run=True)  # Test the data import

        #if not result.has_errors():
        #    person_resource.import_data(dataset, dry_run=False)  # Actually import now

    return render(request, 'input.html')