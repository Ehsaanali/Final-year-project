from import_export import resources
from .models import LHW_Performance

class LHW_PerformanceResource(resources.ModelResource):
    class Meta:
        model = LHW_Performance