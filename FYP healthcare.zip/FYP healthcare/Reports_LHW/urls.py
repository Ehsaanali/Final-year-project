
from django.urls import path
from . import views
urlpatterns =[
path('',views.Reports_LHW, name='Reports_LHW'),




]






