from django.shortcuts import render
from LHW_ReportsWise.models import LHW_ReportsWisee
import pandas as pd

# Create your views here.
def Reports_LHW(request):
    
    
    context = LHW_ReportsWisee.objects.all().values()
     

    return render(request,'Reports_LHW.html',{'context':context})

