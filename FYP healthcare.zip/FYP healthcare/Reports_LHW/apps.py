from django.apps import AppConfig


class ReportsLhwConfig(AppConfig):
    name = 'Reports_LHW'
