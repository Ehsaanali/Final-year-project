from django.urls import path
from . import views
urlpatterns =[
path('',views.LHW_ReportsWise, name='LHW_ReportsWise'),




]









