from django.contrib import admin
from .models import LHW_ReportsWisee

admin.site.register(LHW_ReportsWisee)

# Register your models here.
