from django.apps import AppConfig


class LhwReportswiseConfig(AppConfig):
    name = 'LHW_ReportsWise'
