from django.db import models

# Create your models here.



class LHW_ReportsWisee(models.Model):
    
    District = models.TextField(max_length=255)
    Due_Reports = models.IntegerField()
    Submitted_Reports = models.IntegerField()
    def __str__(self):
        return self.District